import { useEffect, useState } from 'react';
import { toast } from 'react-toastify';

export default function Subscribers() {
  const [subscribers, setSubscribers] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchSubscribers = async () => {
    try {
      const res = await fetch('/api/subscribers');
      const data = await res.json();
      if (data.success) {
        setSubscribers(data.subscribers);
      }
    } catch (error) {
      toast.error('Failed to fetch subscribers');
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchSubscribers();
  }, []);

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this subscriber?')) return;
    try {
      const res = await fetch(`/api/subscribers/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        toast.success(data.message);
        fetchSubscribers();
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      toast.error('Failed to delete subscriber');
    }
  };

  if (loading) return <div className="p-8">Loading subscribers...</div>;

  return (
    <div className="p-8">
      <h2 className="text-3xl font-bold text-slate-800 mb-6">Subscribers</h2>
      <div className="overflow-x-auto bg-white shadow-md rounded-lg">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-100 border-b border-slate-200">
              <th className="py-4 px-6 font-semibold text-slate-700">Email</th>
              <th className="py-4 px-6 font-semibold text-slate-700">Subscribed Date</th>
              <th className="py-4 px-6 font-semibold text-slate-700">Action</th>
            </tr>
          </thead>
          <tbody>
            {subscribers.length === 0 ? (
              <tr>
                <td colSpan="3" className="py-6 text-center text-slate-500">No subscribers found.</td>
              </tr>
            ) : (
              subscribers.map((sub) => (
                <tr key={sub._id} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-4 px-6 font-medium text-slate-800">{sub.email}</td>
                  <td className="py-4 px-6 text-slate-500">
                    {new Date(sub.subscribedAt).toLocaleDateString()}
                  </td>
                  <td className="py-4 px-6">
                    <button
                      onClick={() => handleDelete(sub._id)}
                      className="text-red-500 hover:text-red-700 font-semibold transition"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
