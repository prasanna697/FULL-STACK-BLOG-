import { useState } from 'react';
import { toast } from 'react-toastify';

export default function AddBlog() {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'Technology',
    author: '',
    image: '',
  });

  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    if (e.target.name === 'image') {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setFormData({ ...formData, image: reader.result });
        };
        reader.readAsDataURL(file);
      }
    } else {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/blogs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (data.success) {
        toast.success(data.message);
        setFormData({ title: '', description: '', category: 'Technology', author: '', image: '' });
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      toast.error('Something went wrong');
    }
    setLoading(false);
  };

  return (
    <div className="p-8 max-w-2xl mx-auto">
      <h2 className="text-3xl font-bold text-slate-800 mb-6">Add Blog</h2>
      <form onSubmit={handleSubmit} className="flex flex-col gap-5">
        <div>
          <label className="block text-sm justify-start font-medium text-slate-700 mb-1">Upload Image</label>
          <input type="file" name="image" accept="image/*" onChange={handleChange} required
            className="w-full border border-slate-300 rounded-md p-2 focus:ring-2 focus:ring-indigo-600 focus:outline-none file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100" />
          {formData.image && (
            <div className="mt-4">
              <p className="text-xs text-slate-500 mb-2">Image Preview:</p>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={formData.image} alt="Preview" className="h-32 object-contain rounded-md border border-slate-200" />
            </div>
          )}
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Blog Title</label>
          <input type="text" name="title" value={formData.title} onChange={handleChange} required
            className="w-full border border-slate-300 rounded-md p-2 focus:ring-2 focus:ring-indigo-600 focus:outline-none" />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Author Name</label>
          <input type="text" name="author" value={formData.author} onChange={handleChange} required
            className="w-full border border-slate-300 rounded-md p-2 focus:ring-2 focus:ring-indigo-600 focus:outline-none" />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Category</label>
          <select name="category" value={formData.category} onChange={handleChange}
            className="w-full border border-slate-300 rounded-md p-2 focus:ring-2 focus:ring-indigo-600 focus:outline-none bg-white">
            <option value="Technology">Technology</option>
            <option value="Startup">Startup</option>
            <option value="Lifestyle">Lifestyle</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Blog Description</label>
          <textarea name="description" value={formData.description} onChange={handleChange} required rows="6"
            className="w-full border border-slate-300 rounded-md p-2 focus:ring-2 focus:ring-indigo-600 focus:outline-none"></textarea>
        </div>
        <button type="submit" disabled={loading}
          className="bg-indigo-600 text-white font-semibold py-3 rounded-md hover:bg-indigo-700 transition disabled:bg-indigo-400">
          {loading ? 'Publishing...' : 'Publish Blog'}
        </button>
      </form>
    </div>
  );
}
