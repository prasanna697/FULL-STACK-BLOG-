export default function AdminSidebar({ activeSection, setActiveSection }) {
  const menuItems = [
    { id: 'addBlog', label: 'Add Blog' },
    { id: 'blogList', label: 'Blog List' },
    { id: 'subscribers', label: 'Subscribers' },
  ];

  return (
    <div className="w-64 min-h-screen bg-slate-900 text-white p-5 flex flex-col">
      <h2 className="text-2xl font-bold mb-8 text-center border-b border-slate-700 pb-4">
        Admin Panel
      </h2>
      <nav className="flex flex-col gap-4">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveSection(item.id)}
            className={`text-left px-4 py-3 rounded-md transition-colors ${
              activeSection === item.id
                ? 'bg-indigo-600 font-semibold'
                : 'hover:bg-slate-800 text-slate-300'
            }`}
          >
            {item.label}
          </button>
        ))}
      </nav>
    </div>
  );
}
