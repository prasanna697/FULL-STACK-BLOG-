import { useEffect, useState } from 'react';
import { toast } from 'react-toastify';

export default function BlogList() {
  const [blogs, setBlogs] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchBlogs = async () => {
    try {
      const res = await fetch('/api/blogs');
      const data = await res.json();
      if (data.success) {
        setBlogs(data.blogs);
      }
    } catch (error) {
      toast.error('Failed to fetch blogs');
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchBlogs();
  }, []);

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this blog?')) return;
    try {
      const res = await fetch(`/api/blogs/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        toast.success(data.message);
        fetchBlogs();
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      toast.error('Failed to delete blog');
    }
  };

  if (loading) return <div className="p-8">Loading blogs...</div>;

  return (
    <div className="p-8">
      <h2 className="text-3xl font-bold text-slate-800 mb-6">Blog List</h2>
      <div className="overflow-x-auto bg-white shadow-md rounded-lg">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-100 border-b border-slate-200">
              <th className="py-4 px-6 font-semibold text-slate-700">Author Name</th>
              <th className="py-4 px-6 font-semibold text-slate-700">Blog Title</th>
              <th className="py-4 px-6 font-semibold text-slate-700">Date</th>
              <th className="py-4 px-6 font-semibold text-slate-700">Action</th>
            </tr>
          </thead>
          <tbody>
            {blogs.length === 0 ? (
              <tr>
                <td colSpan="4" className="py-6 text-center text-slate-500">No blogs found.</td>
              </tr>
            ) : (
              blogs.map((blog) => (
                <tr key={blog._id} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-4 px-6">{blog.author}</td>
                  <td className="py-4 px-6 font-medium text-indigo-600">{blog.title}</td>
                  <td className="py-4 px-6 text-slate-500">
                    {new Date(blog.createdAt).toLocaleDateString()}
                  </td>
                  <td className="py-4 px-6">
                    <button
                      onClick={() => handleDelete(blog._id)}
                      className="text-red-500 hover:text-red-700 font-semibold transition"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
