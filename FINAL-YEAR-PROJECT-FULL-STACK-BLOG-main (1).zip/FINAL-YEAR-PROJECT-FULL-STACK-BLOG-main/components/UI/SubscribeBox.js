import { useState } from 'react';
import { toast } from 'react-toastify';

export default function SubscribeBox() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async (e) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    try {
      const res = await fetch('/api/subscribers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success(data.message);
        setEmail('');
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      toast.error('Something went wrong');
    }
    setLoading(false);
  };

  return (
    <div className="bg-gradient-to-b from-indigo-50/50 to-white py-20 text-center border-t border-slate-100 mt-20">
      <div className="max-w-2xl mx-auto px-4">
        <h2 className="text-4xl font-black text-slate-900 mb-5 tracking-tight">Stay in the loop</h2>
        <p className="text-lg text-slate-600 mb-10 max-w-lg mx-auto font-medium">
          Get the latest technology, startup, and lifestyle news delivered straight to your inbox.
        </p>
        <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto relative">
          <input
            type="email"
            placeholder="Enter your email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="flex-1 px-6 py-4 rounded-full border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-transparent text-slate-700 placeholder-slate-400 shadow-sm text-lg transition-shadow"
          />
          <button
            type="submit"
            disabled={loading}
            className="px-8 py-4 bg-slate-900 text-white rounded-full font-bold hover:bg-indigo-600 transition-all shadow-lg hover:shadow-indigo-600/25 disabled:bg-slate-400 whitespace-nowrap text-lg sm:absolute sm:right-1.5 sm:top-1.5 sm:bottom-1.5 sm:py-0"
          >
            {loading ? 'Subscribing...' : 'Subscribe'}
          </button>
        </form>
      </div>
    </div>
  );
}
