import Link from 'next/link';

export default function BlogCard({ blog }) {
  return (
    <div className="bg-white rounded-2xl shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] border border-slate-100 overflow-hidden hover:shadow-[0_8px_30px_-4px_rgba(0,0,0,0.1)] transition-all duration-300 hover:-translate-y-1 group flex flex-col h-full">
      <div className="relative h-56 overflow-hidden shrink-0">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img 
          src={(blog.image && (blog.image.startsWith('http') || blog.image.startsWith('data:'))) ? blog.image : 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80'} 
          alt={blog.title} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out" 
          onError={(e) => { e.target.src = 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80'; }}
        />
        <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm text-indigo-700 text-[10px] font-bold px-3 py-1.5 rounded-full uppercase tracking-widest shadow-sm">
          {blog.category}
        </div>
      </div>
      <div className="p-6 flex flex-col flex-1">
        <h3 className="text-xl font-bold text-slate-800 mb-3 line-clamp-2 leading-snug group-hover:text-indigo-600 transition-colors">
          {blog.title}
        </h3>
        <p className="text-slate-500 text-sm mb-4 line-clamp-3 leading-relaxed flex-1">
          {blog.description}
        </p>
        <div className="flex items-center justify-between mt-auto pt-5 border-t border-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-100 to-indigo-50 flex items-center justify-center text-indigo-700 font-bold text-xs shadow-inner">
              {blog.author ? blog.author.charAt(0).toUpperCase() : '?'}
            </div>
            <span className="text-sm font-semibold text-slate-700">{blog.author || 'Unknown'}</span>
          </div>
          <Link href={`/blog/${blog._id}`} className="text-indigo-600 font-bold text-sm hover:text-indigo-800 transition-colors flex items-center gap-1 group/link">
            Read <span className="group-hover/link:translate-x-1 transition-transform">&rarr;</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
