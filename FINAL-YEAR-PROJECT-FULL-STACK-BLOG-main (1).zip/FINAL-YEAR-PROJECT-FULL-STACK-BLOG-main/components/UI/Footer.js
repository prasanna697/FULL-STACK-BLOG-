export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-400 py-12 text-center border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4">
        <p className="font-medium text-sm">
          &copy; {new Date().getFullYear()} Blogger App. Made with built-in aesthetics.
        </p>
      </div>
    </footer>
  );
}
