import Link from 'next/link';

export default function Navbar() {
  return (
    <nav className="bg-slate-900 border-b border-slate-800 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-2xl font-black tracking-tight text-white hover:text-indigo-400 transition-colors">
              Blogger.<span className="text-indigo-500">app</span>
            </span>
          </Link>
          <div className="flex items-center">
            <button className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-2.5 rounded-full font-bold transition-all shadow-lg shadow-indigo-600/30">
              Get Started
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
