import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import Head from 'next/head';
import Link from 'next/link';

export default function BlogDetail() {
  const router = useRouter();
  const { id } = router.query;
  
  const [blog, setBlog] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    const fetchBlog = async () => {
      try {
        const res = await fetch(`/api/blogs/${id}`);
        const data = await res.json();
        if (data.success) {
          setBlog(data.blog);
        }
      } catch (error) {
        console.error('Failed to fetch blog');
      }
      setLoading(false);
    };
    fetchBlog();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-slate-200 border-t-indigo-600"></div>
      </div>
    );
  }

  if (!blog) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center text-center px-4">
        <h2 className="text-3xl font-bold text-slate-800 mb-4">Blog not found</h2>
        <p className="text-slate-500 mb-8">The blog post you're looking for doesn't exist.</p>
        <Link href="/" className="px-6 py-3 bg-indigo-600 text-white rounded-full font-bold hover:bg-indigo-700 transition">
          Return Home
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      <Head>
        <title>{blog.title} - Blogger App</title>
      </Head>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-16">
        <Link href="/" className="inline-flex items-center text-indigo-600 hover:text-indigo-800 font-semibold mb-8 group">
          <span className="group-hover:-translate-x-1 transition-transform mr-2">&larr;</span> Back to all blogs
        </Link>
        
        <div className="mb-10 text-center">
          <span className="inline-block px-4 py-1.5 rounded-full bg-indigo-100 text-indigo-800 font-bold text-xs uppercase tracking-widest mb-6">
            {blog.category}
          </span>
          <h1 className="text-4xl md:text-5xl lg:text-7xl font-black text-slate-900 mb-8 leading-tight tracking-tight">
            {blog.title}
          </h1>
          <div className="flex items-center justify-center gap-4 text-slate-600 font-medium">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-100 to-indigo-50 flex items-center justify-center text-indigo-700 font-bold text-sm shadow-inner">
                {blog.author ? blog.author.charAt(0).toUpperCase() : '?'}
              </div>
              <span className="text-lg">{blog.author || 'Unknown'}</span>
            </div>
            <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>
            <time className="text-lg">{new Date(blog.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</time>
          </div>
        </div>

        <div className="rounded-3xl overflow-hidden shadow-2xl mb-16 border border-slate-100 bg-white">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img 
            src={(blog.image && (blog.image.startsWith('http') || blog.image.startsWith('data:'))) ? blog.image : 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80'} 
            alt={blog.title} 
            className="w-full h-auto max-h-[600px] object-cover" 
            onError={(e) => { e.target.src = 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80'; }}
          />
        </div>

        <div className="prose prose-lg prose-indigo max-w-none prose-p:text-slate-700 prose-p:leading-relaxed prose-headings:text-slate-900 mx-auto bg-white p-8 md:p-14 rounded-3xl shadow-sm border border-slate-100 text-lg">
          <p className="whitespace-pre-line">{blog.description}</p>
        </div>
      </div>
    </div>
  );
}
