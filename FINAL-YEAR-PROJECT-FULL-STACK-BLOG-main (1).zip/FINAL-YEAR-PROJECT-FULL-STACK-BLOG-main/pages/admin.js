import { useState } from 'react';
import Head from 'next/head';
import AdminSidebar from '../components/Admin/AdminSidebar';
import AddBlog from '../components/Admin/AddBlog';
import BlogList from '../components/Admin/BlogList';
import Subscribers from '../components/Admin/Subscribers';

export default function AdminPage() {
  const [activeSection, setActiveSection] = useState('addBlog');

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Head>
        <title>Admin Dashboard - Blogger App</title>
      </Head>
      
      {/* Sidebar Area */}
      <AdminSidebar activeSection={activeSection} setActiveSection={setActiveSection} />

      {/* Main Content Area */}
      <div className="flex-1 max-h-screen overflow-y-auto">
        {activeSection === 'addBlog' && <AddBlog />}
        {activeSection === 'blogList' && <BlogList />}
        {activeSection === 'subscribers' && <Subscribers />}
      </div>
    </div>
  );
}
