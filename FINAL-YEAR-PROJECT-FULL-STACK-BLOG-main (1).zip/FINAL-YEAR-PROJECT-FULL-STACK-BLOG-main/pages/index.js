import Head from 'next/head';
import { useEffect, useState } from 'react';
import BlogCard from '../components/UI/BlogCard';
import SubscribeBox from '../components/UI/SubscribeBox';

export default function Home() {
  const [blogs, setBlogs] = useState([]);
  const [filteredBlogs, setFilteredBlogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('All');

  const categories = ['All', 'Technology', 'Startup', 'Lifestyle'];

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const res = await fetch('/api/blogs');
        const data = await res.json();
        if (data.success) {
          setBlogs(data.blogs);
          setFilteredBlogs(data.blogs);
        }
      } catch (error) {
        console.error('Failed to fetch blogs');
      }
      setLoading(false);
    };
    fetchBlogs();
  }, []);

  const handleCategoryChange = (category) => {
    setActiveCategory(category);
    if (category === 'All') {
      setFilteredBlogs(blogs);
    } else {
      setFilteredBlogs(blogs.filter((blog) => blog.category === category));
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <Head>
        <title>Blogger App - Latest Insights</title>
      </Head>

      {/* Hero Section */}
      <section className="pt-24 pb-16 text-center px-4">
        <h1 className="text-5xl md:text-7xl font-black text-slate-900 tracking-tight mb-6">
          Latest <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 to-indigo-700">Blogs</span>
        </h1>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto font-medium">
          Discover insights, strategies, and stories from the frontier of technology and lifestyle.
        </p>
      </section>

      {/* Subscription Section */}
      <div className="mb-20">
        <SubscribeBox />
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 bg-slate-50">
        
        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-3 mb-16">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => handleCategoryChange(cat)}
              className={`px-6 py-2.5 rounded-full font-bold text-sm transition-all shadow-sm ${
                activeCategory === cat
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-300 hover:bg-slate-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Blog Grid */}
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-10 w-10 border-4 border-slate-200 border-t-indigo-600"></div>
          </div>
        ) : filteredBlogs.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredBlogs.map((blog) => (
              <BlogCard key={blog._id} blog={blog} />
            ))}
          </div>
        ) : (
          <div className="text-center py-32 bg-white rounded-3xl border border-slate-100 shadow-sm">
            <h3 className="text-2xl font-bold text-slate-800 mb-3">No blogs found</h3>
            <p className="text-slate-500">Try selecting a different category or check back later.</p>
          </div>
        )}
      </main>
    </div>
  );
}
