import ConnectDB from '../../../lib/mongodb';
import Blog from '../../../models/Blog';

export default async function handler(req, res) {
  await ConnectDB();

  const { id } = req.query;

  if (req.method === 'GET') {
    try {
      const blog = await Blog.findById(id);
      if (!blog) {
        return res.status(404).json({ success: false, message: 'Blog not found' });
      }
      return res.status(200).json({ success: true, blog });
    } catch (error) {
      return res.status(500).json({ success: false, message: 'Server error' });
    }
  }

  if (req.method === 'DELETE') {
    try {
      const deletedBlog = await Blog.findByIdAndDelete(id);
      if (!deletedBlog) {
        return res.status(404).json({ success: false, message: 'Blog not found' });
      }
      return res.status(200).json({ success: true, message: 'Blog deleted successfully' });
    } catch (error) {
      return res.status(500).json({ success: false, message: 'Server error' });
    }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}
