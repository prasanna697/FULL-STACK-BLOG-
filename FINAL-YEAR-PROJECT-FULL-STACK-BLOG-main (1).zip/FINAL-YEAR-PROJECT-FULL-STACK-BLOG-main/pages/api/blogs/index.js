import ConnectDB from '../../../lib/mongodb';
import Blog from '../../../models/Blog';

export const config = {
  api: {
    bodyParser: {
      sizeLimit: '10mb',
    },
  },
};

export default async function handler(req, res) {
  await ConnectDB();

  if (req.method === 'GET') {
    try {
      const blogs = await Blog.find({}).sort({ createdAt: -1 });
      return res.status(200).json({ success: true, blogs });
    } catch (error) {
      return res.status(500).json({ success: false, message: 'Failed to fetch blogs' });
    }
  }

  if (req.method === 'POST') {
    try {
      const { title, description, category, author, image } = req.body;
      const newBlog = await Blog.create({
        title,
        description,
        category,
        author,
        image,
      });
      return res.status(201).json({ success: true, blog: newBlog, message: 'Blog added successfully' });
    } catch (error) {
      return res.status(500).json({ success: false, message: 'Failed to add blog' });
    }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}
