import ConnectDB from '../../../lib/mongodb';
import Subscriber from '../../../models/Subscriber';

export default async function handler(req, res) {
  await ConnectDB();

  if (req.method === 'GET') {
    try {
      const subscribers = await Subscriber.find({}).sort({ subscribedAt: -1 });
      return res.status(200).json({ success: true, subscribers });
    } catch (error) {
      return res.status(500).json({ success: false, message: 'Failed to fetch subscribers' });
    }
  }

  if (req.method === 'POST') {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ success: false, message: 'Email is required' });
      }
      
      const existing = await Subscriber.findOne({ email: email.toLowerCase() });
      if (existing) {
        return res.status(400).json({ success: false, message: 'Email already subscribed' });
      }

      const subscriber = await Subscriber.create({ email });
      return res.status(201).json({ success: true, subscriber, message: 'Subscribed successfully' });
    } catch (error) {
      return res.status(500).json({ success: false, message: 'Failed to subscribe' });
    }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}
