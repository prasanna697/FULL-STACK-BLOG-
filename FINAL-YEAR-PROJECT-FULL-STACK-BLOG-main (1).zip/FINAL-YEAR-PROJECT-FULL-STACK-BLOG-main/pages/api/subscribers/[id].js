import ConnectDB from '../../../lib/mongodb';
import Subscriber from '../../../models/Subscriber';

export default async function handler(req, res) {
  await ConnectDB();

  const { id } = req.query;

  if (req.method === 'DELETE') {
    try {
      const deletedSubscriber = await Subscriber.findByIdAndDelete(id);
      if (!deletedSubscriber) {
        return res.status(404).json({ success: false, message: 'Subscriber not found' });
      }
      return res.status(200).json({ success: true, message: 'Subscriber deleted successfully' });
    } catch (error) {
      return res.status(500).json({ success: false, message: 'Server error' });
    }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}
